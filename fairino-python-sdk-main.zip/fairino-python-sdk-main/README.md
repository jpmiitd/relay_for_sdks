# fairino-python-sdk 

Introduction
---------------
This is a Python language SDK library specially designed for fairino collaborative robots.

Documentation
----------------
Please see [Python SDK](https://fair-documentation.readthedocs.io/en/latest/SDKManual/python_intro.html)。
# fairino-cpp-sdk

Introduction
-------------
C++ SDK for FAIRINO collaborative robots for Linux operating systems. Please decompress and use the Linux version of the SDK lib library under the Linux system.

Documentation
----------------
Please check [C++ SDK](https://fair-documentation.readthedocs.io/en/latest/SDKManual/cpp_intro.html)。